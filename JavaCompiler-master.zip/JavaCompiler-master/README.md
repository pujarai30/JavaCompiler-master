This compiler is not complete: only contains lexer and parser.
Java syntax specification is reduced.
